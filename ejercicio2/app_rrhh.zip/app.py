def main():
    print("Aplicación de Recursos Humanos - Demo")
    print("Esta app se desplegaría en un servidor (ejemplo).")


if __name__ == "__main__":
    main()
